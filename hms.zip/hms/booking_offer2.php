<div class="form-group">
    <label for="personal details">Personal details</label>
</div>


<div class="form-group">
    <label for="Title">Title</label>

<div class="row">
  <div class="col-xs-3">
    <select class="form-control" name="title" id="options">
  <option>Mr.</option>
  <option>Ms.</option>
  
</select>
    </div>
    </div>
  </div>

   <div class="form-group">
    <label for="Name">Name</label>
    <input type="text" class="form-control" name="name" id="name" placeholder="name"> 
    
  </div>


   <div class="form-group">
    <label for="mailing address">Mailing Address</label>
   <textarea class="form-control" name="address" id="mailing address" rows="6"></textarea>

  
    </div>

   <div class="form-group">
    <label for="contact_number">Contact Number</label>
   <input type="text" class="form-control bfh-number" data-zeros="true"" data-max="11" name="contact" id="contact_number" placeholder="contact number">

   
  </div>







 
 <input type="submit" value="Submit" id="submit" />
</form>   
                                  
                                    
                                     
                                     
                                     </div>
                                     </div>
                         
                         
                         
                         
                         
                         
                     </div>
                     
                     </div>
                     </div>
					 
					