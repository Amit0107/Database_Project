  
    <nav class="navbar navbar-inverse navbar-static-top no-margin" style="margin:0px;"role="navigation">
       <div class="container-fluid">
           <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-Options-navbar-collapse-1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
             </button>
           <a class="navbar-brand" href="#"><img src="images/Devilwolf.png" style="width: auto; height: 300%;" class="img-responsive"</a>
       
          </div>
           
          <div class="collapse navbar-collapse navbar-right" id="bs-Options-navbar-collapse-1" >
             <ul class="nav navbar-nav">
               
                <li><a href="index.php">Home</a></li>
                <li ><a href="room.php">Room</a></li>
                <li ><a href="Booking.php">Booking</a></li>
                <li ><a href="dinning.php">Resturant</a></li>
                <li ><a href="metting.php">Metting</a></li>
                <li ><a href="feedback.php">Contact Us</a></li>
                <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown">More <b class="caret"></b></a>
                <ul class="dropdown-menu">
                  
                   <li><a href="login.php">Sign in</a></li>
                   <li><a href="signup.php">Sign up</a></li>
                   <li><a href="#">Subscribe us</a></li>
                   
                </ul>


            </li>
            
         </ul>
       </div>
     <div>  
   </nav>
    
  
   