  <div class="container no-margin">
       
         <div class="col-md-6">
              <div class="panel panel-default" align="left">
                   <div class="panel-heading">
                     <h4 class="panel-title">Book Online@</h4>
                   </div>
          

             <div class="panel-body">
               <form method="post" action="Booking1.php">
                 <div class="form-group">
                   <label for="contactname">Checkin</label>
                   <input type="date" class="form-control" name="date1" id="checkin" placeholder="">
                </div>

                <div class="form-group">
                  <label for="contactemail">Checkout</label>
                  <input type="date" class="form-control" name="date" id="checkout" placeholder="">
                </div>
                
                <div class="form-group">
<label for="no_of_rooms">No. Of Rooms</label>
<select class="form-control" name="numroom" id="no_of_rooms">
 
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
</select>
</div>

<div class="form-group">
<label for="no_of_nights">No Of persons</label>
<div class="row">
  <div class="col-xs-3">
<select class="form-control" name="adult" id="no_of_nights ">
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
</select>
</div>
 
  </div>
  </div>
        
        
        
        
        
        
        
        
        
        

                    <div align="right" class="form-group">
                   <input type="submit" name="submit" value="Check Availability">
                   </div>
              </form>
            </div>

          </div>
        </div>
















 <div class="col-md-4" align="right" style="padding-top: 180px;">
                  <h5 class="title" ><u>CONTACT DETAILS</u></h5>
                  <div class="contact_details" >
                    <p >
                      <strong>Hotel DreamyNight</strong>
                      <br /> Bisra Road,Near Railway Station
                      <br />Udit Nagar Rourkela,Odisha 769001
                      <br /> Tel: 9823452510
                      <br /> Fax: 9865234112
                      <br /> Email: 
                      <a href="mailto:sales@dreamynight.com">sales@dreamy.com</a>
                    </p>
                  </div>
        

        </div>

 
       
      
      <div class="col-md-2">
	  
         <iframe src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q=NIT%20Rourkela+(My%20Business%20Name)&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" width="350" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>

		 <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3649.4995142552248!2d90.4156763145038!3d23.83638989140395!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c700023fd427%3A0x641522159780e7e2!2sLe+M%C3%A9ridien+Dhaka!5e0!3m2!1sen!2sbd!4v1460189489537" width="350" height="350" frameborder="0" style="border:0" allowfullscreen></iframe>
!-->
      </div>

    </div>

 </div>